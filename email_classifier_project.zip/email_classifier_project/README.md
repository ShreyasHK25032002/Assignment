# Email Classifier with PII Masking

## How it works
- Masks PII from the input email (name, email, phone, etc.)
- Classifies the email into categories like "Request", "Incident", etc.
- Returns JSON with masked entities, masked text, and predicted category

## API Input Format (POST)
```json
{ "email": "Hello, my name is John Doe..." }
