import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from utils import mask_pii

# Load and preprocess
df = pd.read_csv('combined_emails_with_natural_pii.csv')
df['masked_email'], df['pii_entities'] = zip(*df['email'].map(mask_pii))

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(df['masked_email'], df['type'], test_size=0.2, random_state=42)

# Vectorize and train
vectorizer = TfidfVectorizer()
X_train_vec = vectorizer.fit_transform(X_train)
clf = RandomForestClassifier()
clf.fit(X_train_vec, y_train)

# Prediction function
def classify_email(email_text):
    masked, entities = mask_pii(email_text)
    vec = vectorizer.transform([masked])
    label = clf.predict(vec)[0]
    return {
        "input_email_body": email_text,
        "list_of_masked_entities": entities,
        "masked_email": masked,
        "category_of_the_email": label
    }
