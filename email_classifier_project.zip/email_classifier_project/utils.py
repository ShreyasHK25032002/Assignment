import re

def mask_pii(text):
    entities = []
    patterns = {
        "email": r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b",
        "phone_number": r"\b(?:\+91[-\s]?|0)?[6-9]\d{9}\b",
        "dob": r"\b\d{2}[/-]\d{2}[/-]\d{4}\b",
        "aadhar_num": r"\b\d{4}[\s-]?\d{4}[\s-]?\d{4}\b",
        "credit_debit_no": r"\b(?:\d[ -]*?){13,16}\b",
        "cvv_no": r"\b\d{3}\b",
        "expiry_no": r"\b(0[1-9]|1[0-2])\/?([0-9]{2})\b",
        "full_name": r"\b([A-Z][a-z]+(?:\s[A-Z][a-z]+)+)\b"
    }

    masked_text = text
    for label, pattern in patterns.items():
        for match in re.finditer(pattern, masked_text):
            start, end = match.span()
            entity = match.group()
            entities.append({
                "position": [start, end],
                "classification": label,
                "entity": entity
            })
            masked_text = masked_text.replace(entity, f"[{label}]")
    
    return masked_text, entities
