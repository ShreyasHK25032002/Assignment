from fastapi import FastAPI, Request
from pydantic import BaseModel
from models import classify_email

app = FastAPI()

class EmailInput(BaseModel):
    email: str

@app.post("/")
async def classify(input_data: EmailInput):
    result = classify_email(input_data.email)
    return result
